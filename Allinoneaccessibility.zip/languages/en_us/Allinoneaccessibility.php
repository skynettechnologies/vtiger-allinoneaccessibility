<?php

$languageStrings = array(
        'All in One Accessibility' => 'All in One Accessibility™'
);